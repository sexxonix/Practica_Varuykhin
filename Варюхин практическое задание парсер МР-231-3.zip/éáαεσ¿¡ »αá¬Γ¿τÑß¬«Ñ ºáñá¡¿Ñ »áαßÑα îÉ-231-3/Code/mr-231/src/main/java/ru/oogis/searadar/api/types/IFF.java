package ru.oogis.searadar.api.types;

public enum IFF {
    FRIEND, FOE, UNKNOWN
}
