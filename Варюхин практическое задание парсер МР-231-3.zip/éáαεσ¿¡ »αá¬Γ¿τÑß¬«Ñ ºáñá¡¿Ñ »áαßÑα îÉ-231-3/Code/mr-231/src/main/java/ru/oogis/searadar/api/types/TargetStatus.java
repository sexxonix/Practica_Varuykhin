package ru.oogis.searadar.api.types;

public enum TargetStatus {
    TRACKED, LOST, UNRELIABLE_DATA
}
