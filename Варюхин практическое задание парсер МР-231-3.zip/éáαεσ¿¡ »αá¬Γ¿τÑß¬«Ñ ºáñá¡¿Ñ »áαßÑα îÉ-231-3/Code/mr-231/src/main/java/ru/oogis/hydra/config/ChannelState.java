package ru.oogis.hydra.config;

public enum ChannelState
{
	UNDEFINE, DISABLE, INACTIVE, EXPIRED, ACTIVE, BUZY
}
