package ru.oogis.hydra.util;

public class TargetMovementElements
{
	Double distance;
	Double course;
	Double speed;

	public Double getCourse()
	{
		return course;
	}

	public Double getDistance()
	{
		return distance;
	}

	public Double getSpeed()
	{
		return speed;
	}

//	public void setCourse(Double p_course)
//	{
//		course = p_course;
//	}
//
//	public void setDistance(Double p_distance)
//	{
//		distance = p_distance;
//	}
//
//	public void setSpeed(Double p_speed)
//	{
//		speed = p_speed;
//	}

}
